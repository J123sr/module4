# Package Base

Ce package présente des exemples en lien avec la revue des bases du Java (Methods.java et Recursion.java) mais de manière à présenter les structures introduites dans la section "Préparation à l'orienté-objet" (packages, modules, structs).

Le code se lance seulement via la classe `Run`.

Voir le [README à la racine de ce repo](../README.md#compiler-et-lancer-les-programmes) pour les détails de comment compiler le code et lancer la classe Run.