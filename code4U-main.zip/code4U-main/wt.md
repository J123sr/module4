Pour ajouter Windows Terminal, même dans un compte sans droits d'administrateur.

https://hackmd.io/@ss14/windows-terminal ... litérallement juste les étapes 1 à 4.

Pour lancer PowerShell dans le dossier de téléchargement, simplement ouvrir le dossier dans l'explorateur et taper "powershell" dans la barre d'adresse.
